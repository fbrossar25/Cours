/*********************************************************************************/
/* Optimized and multithreaded matrix product                                    */
/* S. Vialle - october 2014                                                      */
/*********************************************************************************/

void LocalMatrixInit(void);
void usage(int ExitCode, FILE *std);
void CommandLineParsing(int argc, char *argv[]);


