Oracle NoSQL Database 12cR1.3.5.2 Community Edition: 2015-12-03 08:34:31 UTC

This is Oracle NoSQL Database, version 12cR1.3.5.2 Community Edition.

To view the release and installation documentation, load the
distribution file doc/index.html into your web browser.
