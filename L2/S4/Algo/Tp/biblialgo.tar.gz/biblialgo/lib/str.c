#include "str.h"

size_t str_length(const char *str) {

  return 0;
}

int str_compare(const char *str1, const char *str2) {

  return 0;
}

const char *str_search(const char *haystack, const char *needle) {

  return NULL;
}
