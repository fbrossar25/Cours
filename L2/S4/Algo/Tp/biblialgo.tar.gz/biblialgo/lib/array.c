#include "array.h"

void array_create(struct array *self) {

}

void array_destroy(struct array *self) {

}

bool array_equals(const struct array *self, const int *content, size_t size) {

  return false;
}

void array_add(struct array *self, int value) {

}

void array_insert(struct array *self, int value, size_t index) {

}

void array_remove(struct array *self, size_t index) {

}

int *array_get(const struct array *self, size_t index) {

  return NULL;
}

bool array_is_empty(const struct array *self) {

  return false;
}

size_t array_size(const struct array *self) {

  return 0;
}

size_t array_search(const struct array *self, int value) {

  return 0;
}

size_t array_search_sorted(const struct array *self, int value) {

  return 0;
}

void array_import(struct array *self, const int *other, size_t size) {

}

void array_dump(const struct array *self) {

}

bool array_is_sorted(const struct array *self) {

  return false;
}

void array_selection_sort(struct array *self) {

}

void array_bubble_sort(struct array *self) {

}

void array_insertion_sort(struct array *self) {

}


void array_quick_sort(struct array *self) {

}

void array_heap_sort(struct array *self) {

}


bool array_is_heap(const struct array *self) {
  return false;
}

void array_heap_add(struct array *self, int value) {

}

int array_heap_top(const struct array *self) {
  return 0;
}

void array_heap_remove_top(struct array *self) {

}
