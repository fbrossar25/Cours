struct list {
  int data;
  struct list *next;
};
