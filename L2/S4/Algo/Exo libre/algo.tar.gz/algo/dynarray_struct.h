struct array {
  int *data;        // tableau
  size_t capacity;  // nombre d'éléments maximum du tableau
  size_t size;      // nombre d'éléments du tableaux
};
