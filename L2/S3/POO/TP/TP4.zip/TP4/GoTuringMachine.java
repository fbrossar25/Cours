public class GoTuringMachine{
	static void config (TuringMachine m, boolean [] cfg){
		while(m.goLeft());
		int i=0;
		do{
			if(cfg[i]) m.write();
			else m.erase();
			i++;
		}while(m.goRight());
		System.out.println("Etat apres configuration :\n"+m);
	}
	
	static void codeWrite(Program p){
		p.add(1, false, "r", 1);
		p.add(1, true, "r", 2);
		p.add(2, true, "r", 2);
		p.add(2, false, "wr", 3);
		p.add(3, true, "r", 3);
		p.add(3, false, "le", 0);
	}
	
	public static void main(String[]args){
		TuringMachine m = new TuringMachine(14);
		Program prog = new Program("ADDITION" , 6);
		boolean cfg[] = {false,false,true,true,true,false,true,true,true,true,true,false,false,false};
		config(m,cfg);
		m.goTo(6);
		System.out.println("Fin de la configuration :\n"+m);
		Instruction i = new Instruction(1,true,"r",1);
		System.out.println(i);
		codeWrite(prog);
		while(m.goLeft()){}
		System.out.println("\n\n"+prog+"\n\n");
		System.out.println(m+"\n\n");
		System.out.println("\n\nPROCESS BEGIN\n\n");
		m.process(prog);
		System.out.println(m);
		System.out.println("\n\nPROCESS END\n\n");
	}
}
