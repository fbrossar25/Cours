public class BadIndexesException extends Exception {
        BadIndexesException() {
            super();
        }

        BadIndexesException(String message) {
            super(message);
        }
}
