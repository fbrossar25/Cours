import java.util.*;

public class Hasard {
    public static Random seed = new Random();
    
    public static int entierRel() {
        return Hasard.seed.nextInt();
    }

    public static int entierRel(int borne) {
	if (Hasard.entier(2) == 0)
	    return Hasard.entier(borne);
	else
	    return 0-Hasard.entier(borne);
    }
    
    public static int entier() {
	return Math.abs(Hasard.entierRel());
    }
    
    public static int entier(int borneSup) {
        return Hasard.entier()%borneSup;
    }

    public static int entier(int borneInf, int borneSup) {
	return borneInf + Hasard.entier(borneSup - borneInf);
    }
    
    public static short entCourtRel() {
        return (short) Hasard.seed.nextInt();
    }
    
    public static short entCourt() {
        return (short) Math.abs(Hasard.entCourtRel());
    }
    
    
}
