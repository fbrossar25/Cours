public class ExempleExcep {

    public static String subArrayString(int[] tab, int from, int to) 
                                          throws BadIndexesException {
        if (from < 0 || from >= tab.length || to < 0 || to >= tab.length)
            throw new BadIndexesException("Les indices "+from+" et "+to+
               " doivent �tre dans l'intervalle [0, "+(tab.length-1)+"]");

        if (from > to)
            throw new BadIndexesException("L'indice de d�but "+from+
                         " doit �tre plus petit que l'indice de fin "+to);

        // Si ce point est atteint, alors on n'a pas lev� d'exception. 
        // Les indices sont corrects, on peut commencer le traitement 
        // sans risque.
        String sas = "[";
        for (int i=from; i <= to; i++) {
            sas += tab[i];
            if (i < to)
                sas += ", ";
        }
        return sas+"]";
    }

    public static void printSubArrayString1(int[] tab, int from, int to) 
                                              throws BadIndexesException {
        // version 1 : l'exception, si elle se produit, ne fait que transiter 
        // sans �tre trait�e
        System.out.println("de "+from+" � "+to+" : "+subArrayString(tab, from, to));
    }

    public static void printSubArrayString2(int[] tab, int from, int to) {
        // version 2 : l'exception, si elle se produit, est saisie (ou arr�t�e)
        try {
            System.out.println("de "+from+" � "+to+" : "+subArrayString(tab, from, to));
        }
        catch (BadIndexesException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) throws BadIndexesException {
        // Selon les ex�cutions (au hasard), ce programme peut s'ex�cuter 
        // avec ou sans erreur (ou exception). Si une exception se produit
        // le programme peut soit planter (cas 1, exception non rattrap�e),
        // soit arriver quand m�me � son terme (cas 2, exception rattrap�e)

        int[] tab = new int[20];

        for (int i=0; i < tab.length; i++)
            tab[i] = i; // on remplit par les valeurs de 0 � 19

        // On g�n�re les indices au hasard
        int from = Hasard.entier(20)-3;
        int to = Hasard.entier(20)+3;

        // Cas 1 ou 2 tir� au hasard :
        if (Hasard.entier(2) == 0) {
            System.out.println("Cas 1 : appel non prot�g� par un try");
            printSubArrayString1(tab, from, to);
        }
        else {
            System.out.println("Cas 2 : appel prot�g� par un try");
            printSubArrayString2(tab, from, to);
        }

        // En cas d'exception, ce point ne peut �tre atteint que si celle-ci
        // a �t� rattrap�e (cas 2). Sinon (cas 1), le programme a plant� avant
        // d'atteindre ce point
        System.out.println("FIN NORMALE DU PROGRAMME");
    }
}
