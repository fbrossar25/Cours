#include <stdio.h>
int factorielle(int n){
	int res;
	if(n==1 || n==0) res=1;
	else res=n*factorielle(n-1);
	return res;
	}
int main(){
	int res,n;
	printf("\n n ? \n");
	scanf("%d",&n);
	res=factorielle(n);
	printf("\n %d \n",res);
	return(0);
}
