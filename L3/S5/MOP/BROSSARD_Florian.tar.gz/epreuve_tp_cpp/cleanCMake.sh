rm -rfv Makefile  CMakeFiles CMakeCache.txt 
rm -rfv src/Makefile src/CMakeFiles src/CMakeCache.txt
