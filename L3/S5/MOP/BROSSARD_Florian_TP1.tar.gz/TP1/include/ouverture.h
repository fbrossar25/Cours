//
// Created by florian on 16/09/16.
//

#ifndef MOPO_TP1_OUVERTURE_H
#define MOPO_TP1_OUVERTURE_H

#include "rectangle.h"

class COuverture : public CRectangle
{
public:
    COuverture();
    COuverture(float largeur, float hauteur);
    ~COuverture();
};


#endif //MOPO_TP1_OUVERTURE_H
