//
// Created by florian on 16/09/16.
//

#include "ouverture.h"

COuverture::COuverture() : CRectangle()
{

}

COuverture::COuverture(float largeur, float hauteur) : CRectangle(largeur,hauteur)
{

}

COuverture::~COuverture()
{

}